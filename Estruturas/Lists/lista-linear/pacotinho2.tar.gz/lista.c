#include "lista.h"

void IniciarLista(struct Lista* lista){
	(*lista).ultimo = 0;
}
void PrintarLista(struct Lista* lista){
	if((*lista).ultimo == 0){
		printf("Lista vazia");
		return;
	}
	int cont=(*lista).primeiro;
	for(; cont < (*lista).ultimo; cont++){
		printf("Nome: %s, Chave: %04d, Preço: R$ %.2f\n", (*lista).itens[cont].nome, (*lista).itens[cont].chave, (*lista).itens[cont].preco);
	}
	printf("************************\n");
}
void InsFin(struct Lista* lista){
	char nome[50];
	int chave;
	float preco;
	printf("Digite o nome do item: ");
	scanf("%s", nome);
	printf("Digite a chave do item: ");
	scanf("%d", &chave);
	printf("Digite o preço do item: ");
	scanf("%f", &preco);
	if((*lista).ultimo == 0)
		(*lista).primeiro = 0;
	strcpy((*lista).itens[(*lista).ultimo].nome, nome);
	(*lista).itens[(*lista).ultimo].chave = chave;
	(*lista).itens[(*lista).ultimo].preco = preco;
	(*lista).ultimo++;


}
void RemFin(struct Lista* lista){
	printf("Item %s Removido!", (*lista).itens[(*lista).ultimo].nome);
	(*lista).ultimo--;
}
void RemIni(struct Lista*){
}
void AddNaPos(struct Lista*);
void RemDaPos(struct Lista*);
void RetiraEspecifico(struct Lista*);
